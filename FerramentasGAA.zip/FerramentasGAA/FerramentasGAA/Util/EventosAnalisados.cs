﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FerramentasGAA.Util
{
    public class EventoTerminal
    {
        public String TipoEvento { get; set; }
        public DateTime DataInicio { get; set; }
        public DateTime DataFim { get; set; }
        public TimeSpan Intervalo { get; set; }
        public String Status { get; set; }
    }
}