﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FerramentasGAA.Util;
using System.Globalization;
using ExcelLibrary.SpreadSheet;

namespace FerramentasGAA.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult UploadLog()
        {
            return View();
        }

        [HttpPost]
        public ActionResult EstatisticasPerformance(HttpPostedFileBase log)
        {
            List<EventoTerminal> eventosAnalisados = new List<EventoTerminal>();

            if (log != null && log.ContentLength > 0)
            {
                var fileName = Path.GetFileName(log.FileName);
                var path = Path.Combine(Server.MapPath("~/logs/"), fileName);
                TimeSpan classificadorO, classificadorN;
                //Tempo Inserção e validação do cartão [VC]
                //Tempo Validação da Senha (após digitação até apresentação da Id de Segurança) [VS]
                //Tempo para apresentar tela acesso fácil após exibição da Id de Segurança [AF]
                //Tempo Autorização Saque [AS]
                //Tempo Contagem e Dispensa de Cédulas Saque [CD]
                //Tempo Confirmação Saque [CS]
                Boolean flgPossuiInicioVC = false, flgPossuiInicioVS = false, flgPossuiInicioAF = false, flgPossuiIntermediarioSC = false,
                    flgPossuiIntermediarioOA = false, flgPossuiInicioAS = false, flgPossuiInicioCD = false, flgPossuiInicioCS = false;
                String evtInicioCartao = "tpgComumProtecaoTela.html          @Evento CartaoInserido                        Disparou evento",
                    evtFimCartao = "tpgComumProtecaoTela.html          @EventoLeituraTrack2ChipComplete              Iniciando... Retorno[0]",
                    evtInicioSenha = "tpgIDSenha.html                    @funcTecla                                    Cliente digitou senha. [****]",
                    evtFimSenha = "tpgIDPositiva.html                 @MontaDesafio                                 Finalizando.",
                    evtInicioAcessoFacil = "tpgIDPositiva.html                 @funcTela                                     Cliente digitou identificacao de seguranca. [***]",
                    evtIntermediarioAcessoFacilSC = "tpgIDPositiva.html                 @VerificaSenha                                objMaestro.ValidarIdentificacaoSeguranca executou com sucesso. [<resposta><indicadorErro>0</indicadorErro>",
                    evtIntermediarioAcessoFacilOA = "tpgIDPositiva.html                 @navTo                                        Navega para [tpgOperacaoAssistida.html]",
                    evtFimAcessoFacilPadrao = "tpgAcessoFacil.html                @ResetTimerDescansoTela                       Iniciando timer",
                    evtFimAcessoFacilACO = "tpgACO.html                        @main                                         Iniciando...",
                    evtFimAcessoFacilACOOferta = "tpgACOOferta.html                  @main                                         Iniciando...",
                    evtInicioSaque = "tpgSaqueMenu.html                  @ProcessarSaque                               Iniciando... Valor",
                    evtInicioSaqueDigitado = "tpgSaqueMenu.html                  @ProcessarSaqueDigitado                       Iniciando... Valor",
                    evtFimSaque = "tpgSaqueProcessa.html              @EfetuarSaqueConfirmado                       Iniciando a dispensa das cédulas",
                    evtInicioCedula = "tpgSaqueProcessa.html              @DispensarValor                               Iniciando...",
                    evtFimCedula = "tpgSaqueProcessa.html              @EventoCashPresentComplete                    Entregou o dinheiro ao Cliente",
                    evtInicioConfirmacaoSaque = "tpgSaqueProcessa.html              @EventoBillsTaken                             Cliente retirou o dinheiro",
                    evtFimConfirmacaoSaque = "tpgSaqueProcessa.html              @ConfirmarSaque                               Fim normal ConfirmarSaque()";


                log.SaveAs(path);

                String[] linhas = System.IO.File.ReadAllLines(path);

                EventoTerminal evtVC = new EventoTerminal();
                EventoTerminal evtVS = new EventoTerminal();
                EventoTerminal evtAF = new EventoTerminal();
                EventoTerminal evtAS = new EventoTerminal();
                EventoTerminal evtCD = new EventoTerminal();
                EventoTerminal evtCS = new EventoTerminal();

                for (int i = 0; i < linhas.Length; i++)
                {
                    //EVENTO INSERÇÃO E VALIDAÇÃO DE CARTÃO
                    if (linhas[i].Contains(evtInicioCartao))
                    {
                        evtVC.TipoEvento = "VC";
                        evtVC.DataInicio = DateTime.ParseExact(linhas[i].Substring(0, 10) + " " + linhas[i].Substring(13, 12), "dd/MM/yyyy HH:mm:ss.fff", CultureInfo.InvariantCulture);
                        flgPossuiInicioVC = true;
                    }
                    else if (flgPossuiInicioVC == true && linhas[i].Contains(evtFimCartao))
                    {
                        evtVC.DataFim = DateTime.ParseExact(linhas[i].Substring(0, 10) + " " + linhas[i].Substring(13, 12), "dd/MM/yyyy HH:mm:ss.fff", CultureInfo.InvariantCulture);
                        evtVC.Intervalo = evtVC.DataFim.Subtract(evtVC.DataInicio);

                        classificadorO = TimeSpan.FromSeconds(4);
                        classificadorN = TimeSpan.FromSeconds(8);

                        if (evtVC.Intervalo <= classificadorO)
                            evtVC.Status = "O";
                        else if (evtVC.Intervalo <= classificadorN)
                            evtVC.Status = "N";
                        else
                            evtVC.Status = "R";

                        eventosAnalisados.Add(evtVC);

                        evtVC = new EventoTerminal();

                        flgPossuiInicioVC = false;
                    }
                    //EVENTO VALIDAÇÃO DE SENHA
                    else if (linhas[i].Contains(evtInicioSenha))
                    {
                        evtVS.TipoEvento = "VS";
                        evtVS.DataInicio = DateTime.ParseExact(linhas[i].Substring(0, 10) + " " + linhas[i].Substring(13, 12), "dd/MM/yyyy HH:mm:ss.fff", CultureInfo.InvariantCulture);
                        flgPossuiInicioVS = true;
                    }
                    else if (flgPossuiInicioVS == true && linhas[i].Contains(evtFimSenha))
                    {
                        evtVS.DataFim = DateTime.ParseExact(linhas[i].Substring(0, 10) + " " + linhas[i].Substring(13, 12), "dd/MM/yyyy HH:mm:ss.fff", CultureInfo.InvariantCulture);
                        evtVS.Intervalo = evtVS.DataFim.Subtract(evtVS.DataInicio);
                        classificadorO = TimeSpan.FromSeconds(4);
                        classificadorN = TimeSpan.FromSeconds(8);

                        if (evtVS.Intervalo <= classificadorO)
                            evtVS.Status = "O";
                        else if (evtVS.Intervalo <= classificadorN)
                            evtVS.Status = "N";
                        else
                            evtVS.Status = "R";

                        eventosAnalisados.Add(evtVS);

                        evtVS = new EventoTerminal();

                        flgPossuiInicioVS = false;
                    }
                    //EVENTO ACESSO FÁCIL
                    else if (linhas[i].Contains(evtInicioAcessoFacil))
                    {
                        evtAF.TipoEvento = "AF";
                        evtAF.DataInicio = DateTime.ParseExact(linhas[i].Substring(0, 10) + " " + linhas[i].Substring(13, 12), "dd/MM/yyyy HH:mm:ss.fff", CultureInfo.InvariantCulture);
                        flgPossuiInicioAF = true;
                        flgPossuiIntermediarioSC = false;
                        flgPossuiIntermediarioOA = false;
                    }
                    else if (flgPossuiInicioAF == true && linhas[i].Contains(evtIntermediarioAcessoFacilSC))
                    {
                        flgPossuiIntermediarioSC = true;
                    }
                    else if (flgPossuiInicioAF == true && flgPossuiIntermediarioSC == true && linhas[i].Contains(evtIntermediarioAcessoFacilOA))
                    {
                        flgPossuiIntermediarioOA = true;
                    }
                    else if ((linhas[i].Contains(evtFimAcessoFacilPadrao) || linhas[i].Contains(evtFimAcessoFacilACO) || linhas[i].Contains(evtFimAcessoFacilACOOferta)) && flgPossuiInicioAF == true && flgPossuiIntermediarioSC == true && flgPossuiIntermediarioOA == true)
                    {
                        evtAF.DataFim = DateTime.ParseExact(linhas[i].Substring(0, 10) + " " + linhas[i].Substring(13, 12), "dd/MM/yyyy HH:mm:ss.fff", CultureInfo.InvariantCulture);
                        evtAF.Intervalo = evtAF.DataFim.Subtract(evtAF.DataInicio);
                        classificadorO = TimeSpan.FromSeconds(4);
                        classificadorN = TimeSpan.FromSeconds(8);

                        if (evtAF.Intervalo <= classificadorO)
                            evtAF.Status = "O";
                        else if (evtAF.Intervalo <= classificadorN)
                            evtAF.Status = "N";
                        else
                            evtAF.Status = "R";

                        eventosAnalisados.Add(evtAF);

                        evtAF = new EventoTerminal();

                        flgPossuiInicioAF = false;
                        flgPossuiIntermediarioSC = false;
                        flgPossuiIntermediarioOA = false;
                    }
                    //EVENTO AUTORIZAÇÃO DE SAQUE
                    else if (linhas[i].Contains(evtInicioSaque) || linhas[i].Contains(evtInicioSaqueDigitado))
                    {
                        evtAS.TipoEvento = "AS";
                        evtAS.DataInicio = DateTime.ParseExact(linhas[i].Substring(0, 10) + " " + linhas[i].Substring(13, 12), "dd/MM/yyyy HH:mm:ss.fff", CultureInfo.InvariantCulture);
                        flgPossuiInicioAS = true;
                    }
                    else if (flgPossuiInicioAS == true && linhas[i].Contains(evtFimSaque))
                    {
                        evtAS.DataFim = DateTime.ParseExact(linhas[i].Substring(0, 10) + " " + linhas[i].Substring(13, 12), "dd/MM/yyyy HH:mm:ss.fff", CultureInfo.InvariantCulture);
                        evtAS.Intervalo = evtAS.DataFim.Subtract(evtAS.DataInicio);
                        classificadorO = TimeSpan.FromSeconds(4);
                        classificadorN = TimeSpan.FromSeconds(8);

                        if (evtAS.Intervalo <= classificadorO)
                            evtAS.Status = "O";
                        else if (evtAS.Intervalo <= classificadorN)
                            evtAS.Status = "N";
                        else
                            evtAS.Status = "R";

                        eventosAnalisados.Add(evtAS);

                        evtAS = new EventoTerminal();

                        flgPossuiInicioAS = false;
                    }
                    //EVENTO CONTAGEM E DISPENSA DE CÉDULAS
                    else if (linhas[i].Contains(evtInicioCedula))
                    {
                        evtCD.TipoEvento = "CD";
                        evtCD.DataInicio = DateTime.ParseExact(linhas[i].Substring(0, 10) + " " + linhas[i].Substring(13, 12), "dd/MM/yyyy HH:mm:ss.fff", CultureInfo.InvariantCulture);
                        flgPossuiInicioCD = true;
                    }
                    else if (flgPossuiInicioCD == true && linhas[i].Contains(evtFimCedula))
                    {
                        evtCD.DataFim = DateTime.ParseExact(linhas[i].Substring(0, 10) + " " + linhas[i].Substring(13, 12), "dd/MM/yyyy HH:mm:ss.fff", CultureInfo.InvariantCulture);
                        evtCD.Intervalo = evtCD.DataFim.Subtract(evtCD.DataInicio);
                        classificadorO = TimeSpan.FromSeconds(35);
                        classificadorN = TimeSpan.FromSeconds(45);

                        if (evtCD.Intervalo <= classificadorO)
                            evtCD.Status = "O";
                        else if (evtCD.Intervalo <= classificadorN)
                            evtCD.Status = "N";
                        else
                            evtCD.Status = "R";

                        eventosAnalisados.Add(evtCD);

                        evtCD = new EventoTerminal();

                        flgPossuiInicioCD = false;
                    }
                    //EVENTO CONFIRMAÇÃO DE SAQUE
                    else if (linhas[i].Contains(evtInicioConfirmacaoSaque))
                    {
                        evtCS.TipoEvento = "CS";
                        evtCS.DataInicio = DateTime.ParseExact(linhas[i].Substring(0, 10) + " " + linhas[i].Substring(13, 12), "dd/MM/yyyy HH:mm:ss.fff", CultureInfo.InvariantCulture);
                        flgPossuiInicioCS = true;
                    }
                    else if (flgPossuiInicioCS == true && linhas[i].Contains(evtFimConfirmacaoSaque))
                    {
                        evtCS.DataFim = DateTime.ParseExact(linhas[i].Substring(0, 10) + " " + linhas[i].Substring(13, 12), "dd/MM/yyyy HH:mm:ss.fff", CultureInfo.InvariantCulture);
                        evtCS.Intervalo = evtCS.DataFim.Subtract(evtCS.DataInicio);
                        classificadorO = TimeSpan.FromSeconds(4);
                        classificadorN = TimeSpan.FromSeconds(8);

                        if (evtCS.Intervalo <= classificadorO)
                            evtCS.Status = "O";
                        else if (evtCS.Intervalo <= classificadorN)
                            evtCS.Status = "N";
                        else
                            evtCS.Status = "R";

                        eventosAnalisados.Add(evtCS);

                        evtCS = new EventoTerminal();

                        flgPossuiInicioCS = false;
                    }
                }

                System.IO.File.Delete(path);
            }

            return View(eventosAnalisados);
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}